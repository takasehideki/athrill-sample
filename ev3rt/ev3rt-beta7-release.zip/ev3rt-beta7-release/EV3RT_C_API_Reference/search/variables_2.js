var searchData=
[
  ['date',['date',['../structfileinfo__t.html#a6ab759d8c1c4a264888440e1f0b874fa',1,'fileinfo_t']]],
  ['distance',['distance',['../structir__seek__t.html#a6268429bb3edb73ff45da8a5bbf3a7b2',1,'ir_seek_t']]]
];
