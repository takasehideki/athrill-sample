var searchData=
[
  ['filesz',['filesz',['../structmemfile__t.html#a523b3798dc64d2e36483e66196110e82',1,'memfile_t']]]
];
