var searchData=
[
  ['stepspeed',['STEPSPEED',['../struct_s_t_e_p_s_p_e_e_d.html',1,'']]],
  ['stepsync',['STEPSYNC',['../struct_s_t_e_p_s_y_n_c.html',1,'']]]
];
