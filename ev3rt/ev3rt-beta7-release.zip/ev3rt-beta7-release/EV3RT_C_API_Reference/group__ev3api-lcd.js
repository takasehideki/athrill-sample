var group__ev3api_lcd =
[
    [ "image_t", "structimage__t.html", [
      [ "data", "structimage__t.html#a735984d41155bc1032e09bece8f8d66d", null ],
      [ "height", "structimage__t.html#a5d8006e753a3e76ff637a4e092bbed71", null ],
      [ "width", "structimage__t.html#a395d15e7c2b09961c1bfd1da6179b64c", null ]
    ] ],
    [ "EV3_LCD_HEIGHT", "group__ev3api-lcd.html#ga956e56f606b10ab5a04882d96aaf3d97", null ],
    [ "EV3_LCD_WIDTH", "group__ev3api-lcd.html#ga63b8fc001bdc7600b8eb34809dbbbc7e", null ],
    [ "lcdcolor_t", "group__ev3api-lcd.html#ga29a41d6aaa6742b6ff7841023a7781fb", [
      [ "EV3_LCD_WHITE", "group__ev3api-lcd.html#gga29a41d6aaa6742b6ff7841023a7781fba29effcfea2a5e1a625020dd301f2512c", null ],
      [ "EV3_LCD_BLACK", "group__ev3api-lcd.html#gga29a41d6aaa6742b6ff7841023a7781fba2c3795c2a09dff8824a49df0bc66b467", null ]
    ] ],
    [ "lcdfont_t", "group__ev3api-lcd.html#gacfa26216c22f39c9d2861015e37b1903", [
      [ "EV3_FONT_SMALL", "group__ev3api-lcd.html#ggacfa26216c22f39c9d2861015e37b1903a9fe43837bbb4586662d8c8a66ff6d358", null ],
      [ "EV3_FONT_MEDIUM", "group__ev3api-lcd.html#ggacfa26216c22f39c9d2861015e37b1903a9724ff2a62acd060ff0df6797b2ac9e2", null ]
    ] ],
    [ "ev3_font_get_size", "group__ev3api-lcd.html#gaec36b70c4609aeeb40672df567c4a41a", null ],
    [ "ev3_image_free", "group__ev3api-lcd.html#ga9a557b39a31afd0fa6b8dc0c1aafedfd", null ],
    [ "ev3_image_load", "group__ev3api-lcd.html#ga9d053062bacfad3421e077c45934ce62", null ],
    [ "ev3_lcd_draw_image", "group__ev3api-lcd.html#ga6d5385e6593c709c665d4a8366b6155a", null ],
    [ "ev3_lcd_draw_line", "group__ev3api-lcd.html#ga755de913d9fc48f816f2ed5c5076c400", null ],
    [ "ev3_lcd_draw_string", "group__ev3api-lcd.html#gad9949e40456ca903ee2bdcf8b8b8effe", null ],
    [ "ev3_lcd_fill_rect", "group__ev3api-lcd.html#gaeca9890ee5e82ad8fe48f8d50b3bd24f", null ],
    [ "ev3_lcd_set_font", "group__ev3api-lcd.html#ga7e98bcaf675c46fab88afc38e90cc077", null ]
];