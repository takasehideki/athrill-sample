var group__ev3api_fs =
[
    [ "memfile_t", "structmemfile__t.html", [
      [ "buffer", "structmemfile__t.html#a368f7094dc38acca20612bbb392552f4", null ],
      [ "buffersz", "structmemfile__t.html#a4741a4da4c1364a2940b4815a50764d0", null ],
      [ "filesz", "structmemfile__t.html#a523b3798dc64d2e36483e66196110e82", null ]
    ] ],
    [ "fileinfo_t", "structfileinfo__t.html", [
      [ "date", "structfileinfo__t.html#a6ab759d8c1c4a264888440e1f0b874fa", null ],
      [ "is_dir", "structfileinfo__t.html#afdc3e9e0bf6660afb965e323b7a31747", null ],
      [ "is_hidden", "structfileinfo__t.html#a5822d4f2e6eb806f147423fc1a56ae6f", null ],
      [ "is_readonly", "structfileinfo__t.html#a820dd1e6bad249e10bb3d237a40d86cd", null ],
      [ "name", "structfileinfo__t.html#a71708dbcdba7461a977328afab955e42", null ],
      [ "size", "structfileinfo__t.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
      [ "time", "structfileinfo__t.html#a93658cf9f03a3303cdb292e655c657e7", null ]
    ] ],
    [ "TMAX_FILENAME_LEN", "group__ev3api-fs.html#ga94da27886a8d380953ee3f2f623623c3", null ],
    [ "serial_port_t", "group__ev3api-fs.html#gadfc0b70260f2ffd57afd8229806bd6bc", [
      [ "EV3_SERIAL_DEFAULT", "group__ev3api-fs.html#ggadfc0b70260f2ffd57afd8229806bd6bca6e9c07a8e969e82e3f97dd0586ac3257", null ],
      [ "EV3_SERIAL_UART", "group__ev3api-fs.html#ggadfc0b70260f2ffd57afd8229806bd6bcab2511b1dfe8205d4d61726bcc15c5ec3", null ],
      [ "EV3_SERIAL_BT", "group__ev3api-fs.html#ggadfc0b70260f2ffd57afd8229806bd6bca62bed1745396ddbd9884f19a6d32617d", null ]
    ] ],
    [ "ev3_bluetooth_is_connected", "group__ev3api-fs.html#ga5879be35470c24601cbc8a647bae2081", null ],
    [ "ev3_memfile_free", "group__ev3api-fs.html#ga7e92f18ee9f6b9875c0191a777983570", null ],
    [ "ev3_memfile_load", "group__ev3api-fs.html#gaa75435a927bdaa6b1b6209b990a2cda1", null ],
    [ "ev3_sdcard_closedir", "group__ev3api-fs.html#gaffdeffb3f095a47382d48a352cd2472a", null ],
    [ "ev3_sdcard_opendir", "group__ev3api-fs.html#ga532e8cc92304f0101e0deeb6cd9fadbf", null ],
    [ "ev3_sdcard_readdir", "group__ev3api-fs.html#ga8baeceaf1dc86c7e9d1a5dbdbd80e34b", null ],
    [ "ev3_serial_open_file", "group__ev3api-fs.html#gaac019d412e55aa7e82791ef708cec551", null ]
];