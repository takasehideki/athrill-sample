var structir__remote__t =
[
    [ "channel", "structir__remote__t.html#ac807969279ec280acf6377e0236a5273", null ]
];