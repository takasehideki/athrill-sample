var structir__seek__t =
[
    [ "distance", "structir__seek__t.html#a6268429bb3edb73ff45da8a5bbf3a7b2", null ],
    [ "heading", "structir__seek__t.html#abc5984273223bcd2ea523f05e2aadfe0", null ]
];