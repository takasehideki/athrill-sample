var classev3api_1_1_motor =
[
    [ "Motor", "classev3api_1_1_motor.html#a1407fab0831060e59200b5e1899e8ed5", null ],
    [ "~Motor", "classev3api_1_1_motor.html#adc242f64558cff05f5f998a0f138152f", null ],
    [ "getBrake", "classev3api_1_1_motor.html#a2631c32658374212598038247e950371", null ],
    [ "getCount", "classev3api_1_1_motor.html#ae12bbb5d67acd7d760d2ac27de27cedd", null ],
    [ "getPort", "classev3api_1_1_motor.html#a8fd7849d8109de379891908f79ff2d7b", null ],
    [ "getPWM", "classev3api_1_1_motor.html#a62c13de2216ce789330ce754245b442d", null ],
    [ "reset", "classev3api_1_1_motor.html#a3aea9deb2a0bfea9ff05a898f4822e31", null ],
    [ "setBrake", "classev3api_1_1_motor.html#ac05161f4f0a54f9011e96afc0b36f1e1", null ],
    [ "setCount", "classev3api_1_1_motor.html#af317f15fc5efec2c0bbe275efba894d5", null ],
    [ "setPWM", "classev3api_1_1_motor.html#a281e8e0218f0d852eef90208a778efb9", null ],
    [ "stop", "classev3api_1_1_motor.html#a8c528baf37154d347366083f0f816846", null ],
    [ "Steering", "classev3api_1_1_motor.html#a91e39e597cbab2759d4dba76655e7ba1", null ]
];