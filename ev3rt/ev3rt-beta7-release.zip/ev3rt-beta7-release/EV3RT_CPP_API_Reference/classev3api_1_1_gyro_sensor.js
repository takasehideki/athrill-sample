var classev3api_1_1_gyro_sensor =
[
    [ "GyroSensor", "classev3api_1_1_gyro_sensor.html#a4b5eceaa0d59fa77de4a9389c47cf100", null ],
    [ "getAngle", "classev3api_1_1_gyro_sensor.html#ac466ee9b23ace114a0c7dc66a55f0a33", null ],
    [ "getAnglerVelocity", "classev3api_1_1_gyro_sensor.html#abc36de0b4db7b0373996bf139859facd", null ],
    [ "reset", "classev3api_1_1_gyro_sensor.html#a3aea9deb2a0bfea9ff05a898f4822e31", null ],
    [ "setOffset", "classev3api_1_1_gyro_sensor.html#ac5e5e38a22d405fe86aa56992ed5fcf4", null ]
];