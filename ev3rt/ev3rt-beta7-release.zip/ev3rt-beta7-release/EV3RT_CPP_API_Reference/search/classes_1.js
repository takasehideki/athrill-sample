var searchData=
[
  ['gyrosensor',['GyroSensor',['../classev3api_1_1_gyro_sensor.html',1,'ev3api']]]
];
