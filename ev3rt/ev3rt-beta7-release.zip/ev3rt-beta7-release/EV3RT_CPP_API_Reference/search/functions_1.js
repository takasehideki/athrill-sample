var searchData=
[
  ['getambient',['getAmbient',['../classev3api_1_1_color_sensor.html#acc44e85bdec1f461287848f422c7d178',1,'ev3api::ColorSensor']]],
  ['getangle',['getAngle',['../classev3api_1_1_gyro_sensor.html#ac466ee9b23ace114a0c7dc66a55f0a33',1,'ev3api::GyroSensor']]],
  ['getanglervelocity',['getAnglerVelocity',['../classev3api_1_1_gyro_sensor.html#abc36de0b4db7b0373996bf139859facd',1,'ev3api::GyroSensor']]],
  ['getbrake',['getBrake',['../classev3api_1_1_motor.html#a2631c32658374212598038247e950371',1,'ev3api::Motor']]],
  ['getbrightness',['getBrightness',['../classev3api_1_1_color_sensor.html#a69a29c6b39fce66d1add48f98bd7f4f1',1,'ev3api::ColorSensor']]],
  ['getcolornumber',['getColorNumber',['../classev3api_1_1_color_sensor.html#a0cb1d918ddc51976152befd4cb7576aa',1,'ev3api::ColorSensor']]],
  ['getcount',['getCount',['../classev3api_1_1_motor.html#ae12bbb5d67acd7d760d2ac27de27cedd',1,'ev3api::Motor']]],
  ['getdistance',['getDistance',['../classev3api_1_1_sonar_sensor.html#a8f78d759e64ee9c5d99041c32f0f108d',1,'ev3api::SonarSensor']]],
  ['getport',['getPort',['../classev3api_1_1_motor.html#a8fd7849d8109de379891908f79ff2d7b',1,'ev3api::Motor::getPort()'],['../classev3api_1_1_sensor.html#aa7b29e15bdf3e8cbce75b9ef2beb2a3f',1,'ev3api::Sensor::getPort()']]],
  ['getpwm',['getPWM',['../classev3api_1_1_motor.html#a62c13de2216ce789330ce754245b442d',1,'ev3api::Motor']]],
  ['getrawcolor',['getRawColor',['../classev3api_1_1_color_sensor.html#a3847793cb8f59fdd82b0e2862585c548',1,'ev3api::ColorSensor']]],
  ['gettim',['getTim',['../classev3api_1_1_clock.html#a6481c3c7e9168faff019887c77b43872',1,'ev3api::Clock']]],
  ['gyrosensor',['GyroSensor',['../classev3api_1_1_gyro_sensor.html#a4b5eceaa0d59fa77de4a9389c47cf100',1,'ev3api::GyroSensor']]]
];
