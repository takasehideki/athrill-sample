var indexSectionsWithContent =
{
  0: "cdegilmnprstw~",
  1: "cgmst",
  2: "p",
  3: "cgilmnrstw~",
  4: "dp",
  5: "e",
  6: "p",
  7: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "全て",
  1: "データ構造",
  2: "ファイル",
  3: "関数",
  4: "変数",
  5: "列挙型",
  6: "列挙値",
  7: "マクロ定義"
};

