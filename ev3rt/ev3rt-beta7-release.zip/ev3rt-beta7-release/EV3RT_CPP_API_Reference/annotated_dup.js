var annotated_dup =
[
    [ "ev3api", null, [
      [ "Clock", "classev3api_1_1_clock.html", "classev3api_1_1_clock" ],
      [ "ColorSensor", "classev3api_1_1_color_sensor.html", "classev3api_1_1_color_sensor" ],
      [ "GyroSensor", "classev3api_1_1_gyro_sensor.html", "classev3api_1_1_gyro_sensor" ],
      [ "Motor", "classev3api_1_1_motor.html", "classev3api_1_1_motor" ],
      [ "Sensor", "classev3api_1_1_sensor.html", "classev3api_1_1_sensor" ],
      [ "SonarSensor", "classev3api_1_1_sonar_sensor.html", "classev3api_1_1_sonar_sensor" ],
      [ "Steering", "classev3api_1_1_steering.html", "classev3api_1_1_steering" ],
      [ "TouchSensor", "classev3api_1_1_touch_sensor.html", "classev3api_1_1_touch_sensor" ]
    ] ]
];