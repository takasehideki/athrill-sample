var classev3api_1_1_sensor =
[
    [ "Sensor", "classev3api_1_1_sensor.html#a07b73ea90f6a17cd9cb49444d7bb70ff", null ],
    [ "~Sensor", "classev3api_1_1_sensor.html#a2ae1cfed88e7d67c96456248c256875c", null ],
    [ "getPort", "classev3api_1_1_sensor.html#aa7b29e15bdf3e8cbce75b9ef2beb2a3f", null ]
];